# Mike Chopswil
* csv data for most of the statblocks

# websterguy#1136
* Macro to allow for importing to sbc