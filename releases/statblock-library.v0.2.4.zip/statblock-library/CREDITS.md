# Mike Chopswil
* csv data for most of the statblocks

# websterguy#1136
* Macro to allow for importing to sbc

# Primer / Lavaeolous
SBC for Pathfinder 1e, with makes this module significantly more useful.