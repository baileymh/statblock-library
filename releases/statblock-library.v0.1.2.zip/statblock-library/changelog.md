# Changelog

## 0.1.2

### Bugfix
- Fixed linebreak on attacks resulting in sbc error

### Changelog
- Added section ids for each statblock

## 0.1.0

- initial release
